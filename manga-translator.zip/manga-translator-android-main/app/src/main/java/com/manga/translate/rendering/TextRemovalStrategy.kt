package com.manga.translate.rendering

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import org.opencv.android.OpenCVLoader
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.RotatedRect
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc

/**
 * Strategy interface for text removal/inpainting methods.
 */
interface TextRemovalStrategy {
    /**
     * Remove text from the source bitmap using the specified method.
     * @param source The source bitmap (will be mutated)
     * @param maskContour Normalized contour coordinates (x,y pairs in 0-1 range)
     * @param bubbleColor The background/bubble color to use for solid fill
     * @param rotationAngle Optional rotation angle in degrees (if text is rotated)
     */
    fun removeText(
        source: Bitmap,
        maskContour: FloatArray,
        bubbleColor: Int,
        rotationAngle: Float = 0f
    )

    /**
     * Check if this strategy is available and ready to use.
     */
    fun isAvailable(): Boolean
}

/**
 * Solid fill text removal implementation.
 */
object SolidFillRemovalStrategy : TextRemovalStrategy {
    override fun removeText(
        source: Bitmap,
        maskContour: FloatArray,
        bubbleColor: Int,
        rotationAngle: Float
    ) {
        if (maskContour.isEmpty() || maskContour.size < 2) return

        val width = source.width.toFloat()
        val height = source.height.toFloat()
        val canvas = android.graphics.Canvas(source)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bubbleColor
            style = Paint.Style.FILL
        }

        val path = android.graphics.Path()
        val points = mutableListOf<android.graphics.PointF>()

        // Convert normalized contour to pixel coordinates
        for (i in 0 until maskContour.size step 2) {
            val x = maskContour[i] * width
            val y = maskContour[i + 1] * height
            points.add(android.graphics.PointF(x, y))
        }

        if (points.size < 3) {
            // Fallback to rect fill if contour is too small
            val bounds = android.graphics.RectF()
            points.forEach { pt ->
                if (bounds.isEmpty()) {
                    bounds.set(pt.x, pt.y, pt.x, pt.y)
                } else {
                    bounds.union(pt.x, pt.y)
                }
            }
            // Expand bounds slightly to cover antialiasing
            val expand = 2f
            bounds.invert(-expand, -expand, expand, expand)
            canvas.drawRect(bounds, paint)
        } else {
            // Build path from contour points
            path.moveTo(points[0].x, points[0].y)
            for (i in 1 until points.size) {
                path.lineTo(points[i].x, points[i].y)
            }
            path.close()

            // Apply rotation if needed around the contour center
            if (rotationAngle != 0f) {
                val cx = points.map { it.x }.average().toFloat()
                val cy = points.map { it.y }.average().toFloat()
                canvas.save()
                canvas.translate(cx, cy)
                canvas.rotate(-rotationAngle)
                canvas.translate(-cx, -cy)
                canvas.drawPath(path, paint)
                canvas.restore()
            } else {
                canvas.drawPath(path, paint)
            }
        }
    }

    override fun isAvailable(): Boolean = true
}

/**
 * OpenCV inpainting text removal implementation.
 */
object OpenCVInpaintingStrategy : TextRemovalStrategy {
    private var openCvLoaded = false
    private val loadLock = Any()

    init {
        // Try to load OpenCV at class initialization
        synchronized(loadLock) {
            if (!openCvLoaded) {
                openCvLoaded = OpenCVLoader.initDebug()
            }
        }
    }

    override fun removeText(
        source: Bitmap,
        maskContour: FloatArray,
        bubbleColor: Int,
        rotationAngle: Float
    ) {
        if (!isAvailable() || maskContour.isEmpty() || maskContour.size < 2) return

        val width = source.width
        val height = source.height

        // Clone source to avoid modifying original during processing
        val srcMat = Mat(width, height, CvType.CV_8UC4)
        val maskMat = Mat(width, height, CvType.CV_8UC1)
        val dstMat = Mat(width, height, CvType.CV_8UC4)

        try {
            // Convert bitmap to OpenCV Mat (ARGB_8888 -> RGBA_8UC4)
            val rgba = Mat()
            android.graphics.BitmapUtils.bitmapToMat(source, rgba)
            rgba.convertTo(srcMat, CvType.CV_8UC4)

            // Create binary mask from contour
            maskMat.setTo(Scalar(0.0))
            val pathPoints = mutableListOf<Point>()

            // Convert normalized contour to pixel coordinates
            for (i in 0 until maskContour.size step 2) {
                val x = (maskContour[i] * width).toInt().coerceAtLeast(0).coerceAtMost(width - 1)
                val y = (maskContour[i + 1] * height).toInt().coerceAtLeast(0).coerceAtMost(height - 1)
                pathPoints.add(Point(x.toDouble(), y.toDouble()))
            }

            if (pathPoints.size >= 3) {
                // Draw filled contour onto mask
                val contour = MatOfPoint()
                contour.fromArray(*pathPoints.toTypedArray())
                val contours = ArrayList<MatOfPoint>()
                contours.add(contour)

                // Apply rotation to contour points if needed
                val rotatedContour = if (rotationAngle != 0f) {
                    val cx = pathPoints.map { it.x }.average()
                    val cy = pathPoints.map { it.y }.average()
                    val rotatedPoints = pathPoints.map { pt ->
                        // Rotate point around contour center
                        val rad = Math.toRadians(rotationAngle.toDouble())
                        val cos = Math.cos(rad)
                        val sin = Math.sin(rad)
                        val dx = pt.x - cx
                        val dy = pt.y - cy
                        val rx = cx + (dx * cos - dy * sin)
                        val ry = cy + (dx * sin + dy * cos)
                        Point(rx, ry)
                    }
                    MatOfPoint().apply { fromArray(*rotatedPoints.toTypedArray()) }
                } else {
                    contour
                }

                Imgproc.drawContours(
                    maskMat,
                    ArrayList<MatOfPoint>().apply { add(rotatedContour) },
                    -1,
                    Scalar(255.0),
                    Core.FILLED
                )
                contour.release()
                rotatedContour.release()
            } else {
                // Fallback: create mask from bounding rect
                val bounds = android.graphics.RectF()
                pathPoints.forEach { pt ->
                    if (bounds.isEmpty()) {
                        bounds.set(pt.x.toFloat(), pt.y.toFloat(), pt.x.toFloat(), pt.y.toFloat())
                    } else {
                        bounds.union(pt.x.toFloat(), pt.y.toFloat())
                    }
                }
                val rect = android.graphics.RectF(
                    bounds.left.coerceAtLeast(0f),
                    bounds.top.coerceAtLeast(0f),
                    bounds.right.coerceAtMost(width.toFloat() - 1),
                    bounds.bottom.coerceAtMost(height.toFloat() - 1)
                )
                // Expand rect slightly
                rect.inset(-2f, -2f)
                Imgproc.rectangle(
                    maskMat,
                    android.graphics.Point(rect.left.toDouble(), rect.top.toDouble()),
                    android.graphics.Point(rect.right.toDouble(), rect.bottom.toDouble()),
                    Scalar(255.0),
                    Core.FILLED
                )
            }

            // Apply inpainting using Navier-Stokes method with conservative radius
            // Radius of 3-5 is conservative for manga speech bubbles (avoids over-smoothing)
            Core.inpaint(
                srcMat,
                maskMat,
                dstMat,
                3.0, // inpaintRadius - conservative value for manga text
                Core.INPAINT_NS // Navier-Stokes inpainting algorithm
            )

            // Copy result back to source bitmap
            android.graphics.BitmapUtils.matToBitmap(dstMat, source)

        } catch (e: Exception) {
            // OpenCV processing failed - fall back to solid fill
            SolidFillRemovalStrategy.removeText(source, maskContour, bubbleColor, rotationAngle)
        } finally {
            // Release all OpenCV native resources
            srcMat.release()
            maskMat.release()
            dstMat.release()
        }
    }

    override fun isAvailable(): Boolean = openCvLoaded

    /**
     * Attempt to reload OpenCV if it failed to initialize initially.
     */
    fun reloadOpenCV(): Boolean {
        synchronized(loadLock) {
            openCvLoaded = OpenCVLoader.initDebug()
            return openCvLoaded
        }
    }
}

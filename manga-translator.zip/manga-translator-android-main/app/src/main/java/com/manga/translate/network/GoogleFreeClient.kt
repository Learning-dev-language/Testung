package com.manga.translate.network

import com.manga.translate.model.TranslationLanguage
import com.manga.translate.platform.AppLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

internal class GoogleFreeClient {
    companion object {
        private const val GOOGLE_URL = "https://translate.googleapis.com/translate_a/single"
        private const val USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Tablet) AppleWebKit/537.36"
        private const val CONNECT_TIMEOUT_MS = 8000
        private const val READ_TIMEOUT_MS = 12000
        private const val MAX_FALLBACK_CONCURRENCY = 5
        
        // Source language code mapping
        private val SOURCE_CODE_MAP = mapOf(
            TranslationLanguage.JA_TO_ZH to "ja",
            TranslationLanguage.EN_TO_ZH to "en",
            TranslationLanguage.KO_TO_ZH to "ko",
            TranslationLanguage.ZH_HANS_TO_TARGET to "zh-CN",
            TranslationLanguage.ZH_HANT_TO_TARGET to "zh-TW",
            TranslationLanguage.FR_TO_ZH to "fr",
            TranslationLanguage.ES_TO_ZH to "es",
            TranslationLanguage.PT_TO_ZH to "pt",
            TranslationLanguage.DE_TO_ZH to "de",
            TranslationLanguage.IT_TO_ZH to "it",
            TranslationLanguage.RU_TO_ZH to "ru",
            TranslationLanguage.CHN_ENG_TO_ZH to "auto" // Mixed Chinese/English
        )
        
        // Target language code mapping
        private val TARGET_CODE_MAP = mapOf(
            TranslationLanguage.JA_TO_ZH to "zh-CN",
            TranslationLanguage.EN_TO_ZH to "zh-CN",
            TranslationLanguage.KO_TO_ZH to "zh-CN",
            TranslationLanguage.ZH_HANS_TO_TARGET to "zh-CN",
            TranslationLanguage.ZH_HANT_TO_TARGET to "zh-TW",
            TranslationLanguage.CHN_ENG_TO_ZH to "zh-CN",
            TranslationLanguage.FR_TO_ZH to "zh-CN",
            TranslationLanguage.ES_TO_ZH to "zh-CN",
            TranslationLanguage.PT_TO_ZH to "zh-CN",
            TranslationLanguage.DE_TO_ZH to "zh-CN",
            TranslationLanguage.IT_TO_ZH to "zh-CN",
            TranslationLanguage.RU_TO_ZH to "zh-CN"
        )
    }

    suspend fun translateBatch(
        texts: List<String>,
        language: TranslationLanguage,
        artificialDelayMs: Int,
    ): List<String?> {
        val start = System.currentTimeMillis()
        val targetCode = TARGET_CODE_MAP[language] ?: "zh-CN"
        
        val queryParam = texts.joinToString("\n") { escapeUrlParam(it) }
        val body = buildString {
            append("client=gtx&")
            append("sl=auto&")
            append("tl=$targetCode&")
            append("dt=t&")
            append("ie=UTF-8&")
            append("oe=UTF-8&")
            append("q=$queryParam")
        }

        val response = executeRequest(body) ?: return failSafe(texts.size)
        val segments = parseGoogleResponse(response) ?: return failSafe(texts.size)
        val results = mapSegmentsToBubbles(texts, segments)
        
        if (artificialDelayMs > 0) {
            val elapsed = System.currentTimeMillis() - start
            val remainingDelay = (artificialDelayMs - elapsed).coerceAtLeast(0)
            if (remainingDelay > 0) delay(remainingDelay)
        }
        
        return results
    }

    private fun failSafe(size: Int): List<String?> = List(size) { null }

    private fun executeRequest(body: String): String? = withContext(Dispatchers.IO) {
        try {
            val url = URL(GOOGLE_URL)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("User-Agent", USER_AGENT)
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = READ_TIMEOUT_MS
            conn.doOutput = true

            conn.outputStream.use { os ->
                os.write(body.toByteArray(StandardCharsets.UTF_8))
            }

            val responseCode = conn.responseCode
            val inputStream: InputStream = if (responseCode in 200..299) {
                conn.inputStream
            } else {
                conn.errorStream ?: return@withContext null
            }

            val response = inputStream.bufferedReader().use { it.readText() }
            response

        } catch (e: Exception) {
            AppLogger.log("GoogleFreeClient", "Request failed", e)
            null
        }
    }

    private fun parseGoogleResponse(json: String): List<Pair<String, String>>? {
        try {
            val segments = mutableListOf<Pair<String, String>>()
            var i = 0
            while (i < json.length) {
                if (json[i] == '[' && i + 1 < json.length && json[i + 1] == '[') {
                    val endSegment = findMatchingBracket(json, i)
                    val segmentText = json.substring(i, endSegment + 1)
                    parseSegment(segmentText)?.let { segments.add(it) }
                    i = endSegment + 1
                } else {
                    i++
                }
            }
            return if (segments.isEmpty()) null else segments
        } catch (e: Exception) {
            AppLogger.log("GoogleFreeClient", "Failed to parse response", e)
            return null
        }
    }

    private fun parseSegment(json: String): Pair<String, String>? {
        try {
            var i = 0
            var translated: String? = null
            var original: String? = null

            while (i < json.length) {
                when (json[i]) {
                    '"' -> {
                        val endQuote = json.indexOf('"', i + 1)
                        if (endQuote == -1) return null
                        val text = json.substring(i + 1, endQuote)
                            .replace("""\\""", "\"")
                            .replace("""\\n""", "\n")
                        if (translated == null) translated = text
                        else if (original == null) original = text
                        i = endQuote + 1
                    }
                    in '0'..'9', '-', '[', ']' -> i = nextTokenEnd(json, i)
                    else -> i++
                }
            }

            return if (translated != null && original != null) {
                Pair(translated, original)
            } else null
        } catch (e: Exception) {
            return null
        }
    }

    private fun nextTokenEnd(json: String, start: Int): Int {
        var i = start
        var bracketCount = 0
        while (i < json.length) {
            when (json[i]) {
                '[' -> bracketCount++
                ']' -> {
                    bracketCount--
                    if (bracketCount == 0) return i + 1
                }
                '"' -> {
                    val end = json.indexOf('"', i + 1)
                    i = if (end == -1) i else end + 1
                }
                ',' -> {
                    if (bracketCount == 0) return i
                }
            }
            i++
        }
        return json.length
    }

    private fun mapSegmentsToBubbles(
        originalTexts: List<String>,
        segments: List<Pair<String, String>>
    ): List<String?> {
        val boundaries = mutableListOf<Int>()
        var cumulative = 0
        for (text in originalTexts) {
            cumulative += text.filter { !it.isWhitespace() }.length
            boundaries.add(cumulative)
        }

        val results = mutableListOf<String?>()
        var segmentIndex = 0
        var currentBoundary = 0
        var boundaryIndex = 0

        while (boundaryIndex < boundaries.size) {
            val boundaryTarget = boundaries[boundaryIndex]
            val accumulatedSegment = StringBuilder()

            while (segmentIndex < segments.size) {
                val segmentOriginal = segments[segmentIndex].second
                val normalizedLen = segmentOriginal.filter { !it.isWhitespace() }.length

                accumulatedSegment.append(segmentOriginal)
                currentBoundary += normalizedLen
                segmentIndex++

                if (currentBoundary >= boundaryTarget) break
            }

            if (accumulatedSegment.isNotEmpty()) {
                val translatedSegments = mutableListOf<String>()
                var tempIdx = segmentIndex - accumulatedSegment.toString().length
                while (tempIdx >= 0 && tempIdx < segmentIndex && 
                       translatedSegments.size < accumulatedSegment.toString().length &&
                       tempIdx >= segmentIndex - 5) {
                    translatedSegments.add(0, segments[tempIdx].first)
                    tempIdx++
                }
                results.add(translatedSegments.joinToString(""))
            } else {
                results.add(null)
            }

            boundaryIndex++
        }

        while (results.size < originalTexts.size) results.add(null)
        return results
    }

    private fun escapeUrlParam(text: String): String {
        return text.replace("%", "%25")
            .replace("&", "%26")
            .replace("=", "%3D")
            .replace("\n", "%0A")
    }

    private fun findMatchingBracket(json: String, start: Int): Int {
        var i = start
        var count = 0
        while (i < json.length) {
            when (json[i]) {
                '[' -> count++
                ']' -> {
                    count--
                    if (count == 0) return i
                }
                '"' -> {
                    val end = json.indexOf('"', i + 1)
                    i = if (end == -1) json.length - 1 else end
                }
            }
            i++
        }
        return json.length - 1
    }
}
